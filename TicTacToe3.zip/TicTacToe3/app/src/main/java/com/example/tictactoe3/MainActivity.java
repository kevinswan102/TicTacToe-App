/*
@author Kevin Swan
 */
package com.example.tictactoe3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //Buttons making up board
    private final Button mBoardButtons[] = new Button[BOARD_SIZE];
    ;

    //Array for game board
    private char mBoard[] = {'1', '2', '3', '4', '5', '6', '7', '8', '9'};

    //Various text displayed
    private TextView mInfoTextView;

    //Game rest button
    private Button mNewGame;


    private static final int BOARD_SIZE = 9;
    private static final char HUMAN_PLAYER = 'X';
    private static final char COMPUTER_PLAYER = 'O';
    private char turn = 'X';
    private int win = 0;
    private int move = -1;
    private Random mRand = new Random();

    private void getComputerMove() {
        int move;

        // First see if there's a move O can make to win
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (mBoard[i] != HUMAN_PLAYER && mBoard[i] != COMPUTER_PLAYER) {
                char curr = mBoard[i];
                mBoard[i] = COMPUTER_PLAYER;
                if (checkForWinner() == 3) {
                    System.out.println("Computer is moving to " + (i + 1));
                    mBoardButtons[i].setText("O");
                    mBoardButtons[i].setEnabled(false);

                    return;
                } else
                    mBoard[i] = curr;
            }
        }

        // See if there's a move O can make to block X from winning
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (mBoard[i] != HUMAN_PLAYER && mBoard[i] != COMPUTER_PLAYER) {
                char curr = mBoard[i];   // Save the current number
                mBoard[i] = HUMAN_PLAYER;
                if (checkForWinner() == 2) {
                    mBoard[i] = COMPUTER_PLAYER;
                    System.out.println("Computer is moving to " + (i + 1));
                    mBoardButtons[i].setText("O");
                    mBoardButtons[i].setEnabled(false);
                    return;
                } else
                    mBoard[i] = curr;
            }
        }

        // Generate random move
        do {
            move = mRand.nextInt(BOARD_SIZE);
        } while (mBoard[move] == HUMAN_PLAYER || mBoard[move] == COMPUTER_PLAYER);

        System.out.println("Computer is moving to " + (move + 1));
        mBoardButtons[move].setText("O");
        mBoardButtons[move].setEnabled(false);

        mBoard[move] = COMPUTER_PLAYER;
    }


    void displayBoard() {
        System.out.println();
        System.out.println(mBoard[0] + " | " + mBoard[1] + " | " + mBoard[2]);
        System.out.println("-----------");
        System.out.println(mBoard[3] + " | " + mBoard[4] + " | " + mBoard[5]);
        System.out.println("-----------");
        System.out.println(mBoard[6] + " | " + mBoard[7] + " | " + mBoard[8]);
        System.out.println();
    }

    int checkForWinner() {
        // Check horizontal wins
        for (int i = 0; i <= 6; i += 3) {
            if (mBoard[i] == HUMAN_PLAYER &&
                    mBoard[i + 1] == HUMAN_PLAYER &&
                    mBoard[i + 2] == HUMAN_PLAYER)
                return 2;
            if (mBoard[i] == COMPUTER_PLAYER &&
                    mBoard[i + 1] == COMPUTER_PLAYER &&
                    mBoard[i + 2] == COMPUTER_PLAYER)
                return 3;
        }

        // Check vertical wins
        for (int i = 0; i <= 2; i++) {
            if (mBoard[i] == HUMAN_PLAYER &&
                    mBoard[i + 3] == HUMAN_PLAYER &&
                    mBoard[i + 6] == HUMAN_PLAYER)
                return 2;
            if (mBoard[i] == COMPUTER_PLAYER &&
                    mBoard[i + 3] == COMPUTER_PLAYER &&
                    mBoard[i + 6] == COMPUTER_PLAYER)
                return 3;
        }

        // Check for diagonal wins
        if ((mBoard[0] == HUMAN_PLAYER &&
                mBoard[4] == HUMAN_PLAYER &&
                mBoard[8] == HUMAN_PLAYER) ||
                (mBoard[2] == HUMAN_PLAYER &&
                        mBoard[4] == HUMAN_PLAYER &&
                        mBoard[6] == HUMAN_PLAYER))
            return 2;
        if ((mBoard[0] == COMPUTER_PLAYER &&
                mBoard[4] == COMPUTER_PLAYER &&
                mBoard[8] == COMPUTER_PLAYER) ||
                (mBoard[2] == COMPUTER_PLAYER &&
                        mBoard[4] == COMPUTER_PLAYER &&
                        mBoard[6] == COMPUTER_PLAYER))
            return 3;

        // Check for tie
        for (int i = 0; i < BOARD_SIZE; i++) {
            // If we find a number, then no one has won yet
            if (mBoard[i] != HUMAN_PLAYER && mBoard[i] != COMPUTER_PLAYER)
                return 0;
        }

        // If we make it through the previous loop, all places are taken, so it's a tie
        return 1;
    }

    void showStatus() {

        System.out.println();
        if (win == 1) {
            System.out.println("It's a tie.");
            mInfoTextView.setText("It's a tie.");
        } else if (win == 2) {
            System.out.println(HUMAN_PLAYER + " wins!");
            mInfoTextView.setText(HUMAN_PLAYER + " wins!");
        } else if (win == 3) {
            System.out.println(COMPUTER_PLAYER + " wins!");
            mInfoTextView.setText(COMPUTER_PLAYER + " wins!");
        }
        //  else{
        // System.out.println("There is a logic problem!");
        //  mInfoTextView.setText("There is a logic problem!"); }
        System.out.println(win);

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mBoardButtons[0] = (Button) findViewById(R.id.square1);
        mBoardButtons[1] = (Button) findViewById(R.id.square2);
        mBoardButtons[2] = (Button) findViewById(R.id.square3);
        mBoardButtons[3] = (Button) findViewById(R.id.square4);
        mBoardButtons[4] = (Button) findViewById(R.id.square5);
        mBoardButtons[5] = (Button) findViewById(R.id.square6);
        mBoardButtons[6] = (Button) findViewById(R.id.square7);
        mBoardButtons[7] = (Button) findViewById(R.id.square8);
        mBoardButtons[8] = (Button) findViewById(R.id.square9);

        //Get reference to the buttons
        mInfoTextView = (TextView) findViewById(R.id.infoLabel);
        mNewGame = (Button) findViewById(R.id.NewGame);

        //Listeners for the buttons
        for (int i = 0; i < mBoardButtons.length; i++) {
            mBoardButtons[i].setText("");
            mBoardButtons[i].setEnabled(true);
            mBoardButtons[i].setOnClickListener(this);
        }
        mNewGame.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {


        switch (v.getId()) {
            case R.id.square1:
                if (win == 0) {

                    if (turn == HUMAN_PLAYER) {


                        turn = COMPUTER_PLAYER;
                        mInfoTextView.setText("Computer's Turn");

                        mBoard[0] = HUMAN_PLAYER;
                        mBoardButtons[0].setText("X");
                        mBoardButtons[0].setEnabled(false);


                        displayBoard();

                        win = checkForWinner();
                        showStatus();
                        if (win == 0) {
                            getComputerMove();
                            turn = HUMAN_PLAYER;
                            mInfoTextView.setText("Human's Turn");
                            displayBoard();
                            win = checkForWinner();
                            showStatus();
                        }
                    }
                }
                break; //do something...

            case R.id.square2:

                if (win == 0) {

                    if (turn == HUMAN_PLAYER) {
                        turn = COMPUTER_PLAYER;
                        mInfoTextView.setText("Computer's Turn");

                        mBoard[1] = HUMAN_PLAYER;
                        mBoardButtons[1].setText("X");
                        mBoardButtons[1].setEnabled(false);

                        displayBoard();
                        win = checkForWinner();
                        showStatus();
                        if (win == 0) {
                            getComputerMove();
                            turn = HUMAN_PLAYER;
                            mInfoTextView.setText("Human's Turn");
                            displayBoard();
                            win = checkForWinner();
                            showStatus();
                        }
                    }
                }
                break; //do something...

            case R.id.square3:
                if (win == 0) {

                    if (turn == HUMAN_PLAYER) {
                        turn = COMPUTER_PLAYER;
                        mInfoTextView.setText("Computer's Turn");

                        mBoard[2] = HUMAN_PLAYER;
                        mBoardButtons[2].setText("X");
                        mBoardButtons[2].setEnabled(false);

                        displayBoard();
                        win = checkForWinner();
                        showStatus();
                        if (win == 0) {
                            getComputerMove();
                            turn = HUMAN_PLAYER;
                            mInfoTextView.setText("Human's Turn");
                            displayBoard();
                            win = checkForWinner();
                            showStatus();
                        }
                    }
                }
                break; //do something...

            case R.id.square4:
                if (win == 0) {

                    if (turn == HUMAN_PLAYER) {
                        turn = COMPUTER_PLAYER;
                        mInfoTextView.setText("Computer's Turn");

                        mBoard[3] = HUMAN_PLAYER;
                        mBoardButtons[3].setText("X");
                        mBoardButtons[3].setEnabled(false);

                        displayBoard();
                        win = checkForWinner();
                        showStatus();
                        if (win == 0) {
                            getComputerMove();
                            turn = HUMAN_PLAYER;
                            mInfoTextView.setText("Human's Turn");
                            displayBoard();
                            win = checkForWinner();
                            showStatus();
                        }
                    }
                }
                break; //do something...

            case R.id.square5:

                if (win == 0) {

                    if (turn == HUMAN_PLAYER) {
                        turn = COMPUTER_PLAYER;
                        mInfoTextView.setText("Computer's Turn");

                        mBoard[4] = HUMAN_PLAYER;
                        mBoardButtons[4].setText("X");
                        mBoardButtons[4].setEnabled(false);

                        displayBoard();
                        win = checkForWinner();
                        showStatus();
                        if (win == 0) {
                            getComputerMove();
                            turn = HUMAN_PLAYER;
                            mInfoTextView.setText("Human's Turn");
                            displayBoard();
                            win = checkForWinner();
                            showStatus();
                        }
                    }
                }
                break; //do something...

            case R.id.square6:

                if (win == 0) {

                    if (turn == HUMAN_PLAYER) {
                        turn = COMPUTER_PLAYER;
                        mInfoTextView.setText("Computer's Turn");

                        mBoard[5] = HUMAN_PLAYER;
                        mBoardButtons[5].setText("X");
                        mBoardButtons[5].setEnabled(false);

                        displayBoard();
                        win = checkForWinner();
                        showStatus();
                        if (win == 0) {
                            getComputerMove();
                            turn = HUMAN_PLAYER;
                            mInfoTextView.setText("Human's Turn");
                            displayBoard();
                            win = checkForWinner();
                            showStatus();
                        }
                    }
                }
                break; //do something...

            case R.id.square7:

                if (win == 0) {

                    if (turn == HUMAN_PLAYER) {
                        turn = COMPUTER_PLAYER;
                        mInfoTextView.setText("Computer's Turn");

                        mBoard[6] = HUMAN_PLAYER;
                        mBoardButtons[6].setText("X");
                        mBoardButtons[6].setEnabled(false);

                        displayBoard();
                        win = checkForWinner();
                        showStatus();
                        if (win == 0) {
                            getComputerMove();
                            turn = HUMAN_PLAYER;
                            mInfoTextView.setText("Human's Turn");
                            displayBoard();
                            win = checkForWinner();
                            showStatus();
                        }
                    }
                }
                break; //do something...

            case R.id.square8:

                if (win == 0) {

                    if (turn == HUMAN_PLAYER) {
                        turn = COMPUTER_PLAYER;
                        mInfoTextView.setText("Computer's Turn");

                        mBoard[7] = HUMAN_PLAYER;
                        mBoardButtons[7].setText("X");
                        mBoardButtons[7].setEnabled(false);

                        displayBoard();
                        win = checkForWinner();
                        showStatus();
                        if (win == 0) {
                            getComputerMove();
                            turn = HUMAN_PLAYER;
                            mInfoTextView.setText("Human's Turn");
                            displayBoard();
                            win = checkForWinner();
                            showStatus();
                        }
                    }
                }
                break; //do something...

            case R.id.square9:

                if (win == 0) {

                    if (turn == HUMAN_PLAYER) {
                        turn = COMPUTER_PLAYER;
                        mInfoTextView.setText("Computer's Turn");

                        mBoard[8] = HUMAN_PLAYER;
                        mBoardButtons[8].setText("X");
                        mBoardButtons[8].setEnabled(false);

                        displayBoard();
                        win = checkForWinner();
                        showStatus();
                        if (win == 0) {
                            getComputerMove();
                            turn = HUMAN_PLAYER;
                            mInfoTextView.setText("Human's Turn");
                            displayBoard();
                            win = checkForWinner();
                            showStatus();
                        }
                    }
                }
                break; //do something...


            case R.id.NewGame:

                for (int i = 0; i < mBoardButtons.length; i++) {
                    mBoardButtons[i].setText("");
                    mBoardButtons[i].setEnabled(true);
                    mBoardButtons[i].setOnClickListener(this);
                }


                mBoard[0] = '1';
                mBoard[1] = '2';
                mBoard[2] = '3';
                mBoard[3] = '4';
                mBoard[4] = '5';
                mBoard[5] = '6';
                mBoard[6] = '7';
                mBoard[7] = '8';
                mBoard[8] = '9';
                mInfoTextView.setText("Human's Turn (X)");

                win = 0;
                turn = 'X';
                move = -1;
                break;
        }


    }
}